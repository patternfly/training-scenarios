import React from 'react';
import "@patternfly/react-core/dist/styles/base.css";
import {
  Brand,
  Button,
  Card,
  CardActions,
  CardHead,
  CardHeader,
  CardBody,
  CardFooter,
  Split,
  SplitItem,
  Text,
  TextContent,
  TextVariants
} from '@patternfly/react-core';
import {
  TimesIcon
} from '@patternfly/react-icons';

function App() {
  return (
      <Card>
      <CardHead>
      <CardActions>
      </CardActions>
      </CardHead>
      <CardHeader>
      </CardHeader>
      <CardBody>
      </CardBody>
      <CardFooter>
      </CardFooter>
      </Card>
);
}

export default App;